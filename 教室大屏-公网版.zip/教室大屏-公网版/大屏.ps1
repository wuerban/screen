﻿# =====================================================================
#  教室大屏  —— Windows 原生窗口版
#
#  特点：
#    · 窗口可以置顶，盖在 PPT 上面
#    · 被最小化 / 被别的窗口挡住时，来新消息会自动还原并弹到最前
#    · 点右上角 X = 最小化到任务栏（程序继续收消息，不会漏）
#    · 右键窗口 → 退出大屏程序（真正结束）
#
#  启动方式：双击「启动大屏.bat」，不要直接右键运行本文件
# =====================================================================

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

# ==================== 改这两行就行 ====================
$ROOM  = '五年级二班'
$TOPIC = 'cls51-7k3m9q2v8x4n'
# ======================================================

$BASE = "https://ntfy.sh/$TOPIC"
$script:LAST    = 0
$script:SEEN    = @{}
$script:BUSY    = $false
$script:EXITING = $false
$script:QR_ON   = $false

function Write-Log($msg) {
  try {
    $p = Join-Path $PSScriptRoot '大屏日志.txt'
    Add-Content -Path $p -Value ("[{0}] {1}" -f (Get-Date -Format 'MM-dd HH:mm:ss'), $msg) -Encoding UTF8
  } catch { }
}

# ---------------------------------------------------------------- 加载界面库
try {
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
} catch {
  Write-Log ("加载界面库失败: " + $_.Exception.Message)
  exit 1
}

# ---------------------------------------------------------------- 窗体
$form = New-Object System.Windows.Forms.Form
$form.Text          = "$ROOM · 大屏"
$form.WindowState   = [System.Windows.Forms.FormWindowState]::Maximized
$form.TopMost       = $true
$form.BackColor     = [System.Drawing.Color]::FromArgb(238, 242, 248)
$form.ShowIcon      = $false
$form.KeyPreview    = $true

$layout = New-Object System.Windows.Forms.TableLayoutPanel
$layout.Dock        = [System.Windows.Forms.DockStyle]::Fill
$layout.ColumnCount = 1
$layout.RowCount    = 2
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100)))
[void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 78)))
$form.Controls.Add($layout)

# ---------------------------------------------------------------- 大字
$lblMsg = New-Object System.Windows.Forms.Label
$lblMsg.Dock      = [System.Windows.Forms.DockStyle]::Fill
$lblMsg.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$lblMsg.ForeColor = [System.Drawing.Color]::FromArgb(13, 27, 42)
$lblMsg.BackColor = [System.Drawing.Color]::Transparent
$lblMsg.Font      = New-Object System.Drawing.Font('Microsoft YaHei', 48, [System.Drawing.FontStyle]::Bold)
$lblMsg.Text      = '大屏已就绪'
[void]$layout.Controls.Add($lblMsg, 0, 0)

# ---------------------------------------------------------------- 二维码层
$qrPanel = New-Object System.Windows.Forms.Panel
$qrPanel.Dock    = [System.Windows.Forms.DockStyle]::Fill
$qrPanel.BackColor = [System.Drawing.Color]::White
$qrPanel.Visible = $false

$qrPic = New-Object System.Windows.Forms.PictureBox
$qrPic.Dock     = [System.Windows.Forms.DockStyle]::Fill
$qrPic.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom

$qrTip = New-Object System.Windows.Forms.Label
$qrTip.Dock      = [System.Windows.Forms.DockStyle]::Bottom
$qrTip.Height    = 54
$qrTip.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$qrTip.Font      = New-Object System.Drawing.Font('Microsoft YaHei', 16)
$qrTip.ForeColor = [System.Drawing.Color]::FromArgb(120, 134, 155)
$qrTip.Text      = '手机扫码打开老师端　·　点「二维码」按钮返回'

[void]$qrPanel.Controls.Add($qrPic)
[void]$qrPanel.Controls.Add($qrTip)
[void]$layout.Controls.Add($qrPanel, 0, 0)

$qrFile = Join-Path $PSScriptRoot '二维码.png'
if (Test-Path $qrFile) {
  try {
    $img = [System.Drawing.Image]::FromFile($qrFile)
    $qrPic.Image = $img
  } catch {
    Write-Log ("二维码图片加载失败: " + $_.Exception.Message)
  }
} else {
  $qrTip.Text = '没找到 二维码.png（不影响收消息）'
}

# ---------------------------------------------------------------- 底部栏
$panelBottom = New-Object System.Windows.Forms.Panel
$panelBottom.Dock      = [System.Windows.Forms.DockStyle]::Fill
$panelBottom.BackColor = [System.Drawing.Color]::FromArgb(238, 242, 248)

$lblMeta = New-Object System.Windows.Forms.Label
$lblMeta.Dock      = [System.Windows.Forms.DockStyle]::Fill
$lblMeta.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblMeta.Padding   = New-Object System.Windows.Forms.Padding(28, 0, 0, 0)
$lblMeta.Font      = New-Object System.Drawing.Font('Microsoft YaHei', 14)
$lblMeta.ForeColor = [System.Drawing.Color]::FromArgb(120, 134, 155)
$lblMeta.Text      = ''
[void]$panelBottom.Controls.Add($lblMeta)

function New-FlatButton($text, $width) {
  $b = New-Object System.Windows.Forms.Button
  $b.Text      = $text
  $b.Dock      = [System.Windows.Forms.DockStyle]::Right
  $b.Width     = $width
  $b.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
  $b.FlatAppearance.BorderSize  = 1
  $b.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(206, 216, 232)
  $b.BackColor = [System.Drawing.Color]::White
  $b.ForeColor = [System.Drawing.Color]::FromArgb(74, 90, 112)
  $b.Font      = New-Object System.Drawing.Font('Microsoft YaHei', 12)
  return $b
}

$btnQR    = New-FlatButton '二维码' 130
$btnClear = New-FlatButton '清屏'   100
[void]$panelBottom.Controls.Add($btnQR)
[void]$panelBottom.Controls.Add($btnClear)
[void]$layout.Controls.Add($panelBottom, 0, 1)

# ---------------------------------------------------------------- 右键菜单（退出）
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$miExit = $menu.Items.Add('退出大屏程序')
[void]$miExit.Add_Click({ $script:EXITING = $true; $form.Close() })
foreach ($c in @($form, $lblMsg, $panelBottom, $lblMeta, $qrPanel, $qrTip)) {
  try { $c.ContextMenuStrip = $menu } catch { }
}

# ---------------------------------------------------------------- 显示逻辑
function Set-BigText($text, $maxSize) {
  if (-not $maxSize) { $maxSize = 200 }
  $w = $lblMsg.ClientSize.Width
  $h = $lblMsg.ClientSize.Height
  if ($w -lt 100) { $w = 1200 }
  if ($h -lt 100) { $h = 600 }
  $availW = $w - 80
  $availH = $h - 60
  $best = 20
  $g = $lblMsg.CreateGraphics()
  for ($s = $maxSize; $s -ge 20; $s -= 4) {
    $f = New-Object System.Drawing.Font('Microsoft YaHei', $s, [System.Drawing.FontStyle]::Bold)
    $sz = $g.MeasureString($text, $f, $availW)
    $f.Dispose()
    if ($sz.Height -le $availH -and $sz.Width -le ($availW + 4)) { $best = $s; break }
  }
  $g.Dispose()
  $lblMsg.Font = New-Object System.Drawing.Font('Microsoft YaHei', $best, [System.Drawing.FontStyle]::Bold)
  $lblMsg.Text = $text
}

function Reset-Screen {
  $script:QR_ON = $false
  $qrPanel.Visible = $false
  $lblMeta.Text = ''
  Set-BigText '大屏已就绪' 100
}

function Show-BigMessage($p) {
  # 还原 + 置顶 + 提到最前
  try {
    if ($form.WindowState -eq [System.Windows.Forms.FormWindowState]::Minimized) {
      $form.WindowState = [System.Windows.Forms.FormWindowState]::Maximized
    }
    $form.ShowInTaskbar = $true
    $form.Show()
    $form.TopMost = $true
    $form.Activate()
    $form.BringToFront()
    [System.Windows.Forms.Application]::DoEvents()
  } catch { Write-Log ("还原窗口失败: " + $_.Exception.Message) }

  $script:QR_ON = $false
  $qrPanel.Visible = $false

  $text = ''
  if ($p.PSObject.Properties.Name -contains 'text') { $text = [string]$p.text }
  if ([string]::IsNullOrWhiteSpace($text)) { $text = '（空消息）' }

  Set-BigText $text 200

  $by = '老师'
  if ($p.PSObject.Properties.Name -contains 'by' -and $p.by) { $by = [string]$p.by }

  $tm = (Get-Date).ToString('HH:mm')
  if ($p.PSObject.Properties.Name -contains 'ts' -and $p.ts) {
    try { $tm = [System.DateTimeOffset]::FromUnixTimeMilliseconds([int64]$p.ts).LocalDateTime.ToString('HH:mm') } catch { }
  }
  $lblMeta.Text = "$by · $tm"

  # 提示音：连着响三下（音量跟随系统音量，调到最大就是最大）
  try {
    [System.Media.SystemSounds]::Exclamation.Play()
    Start-Sleep -Milliseconds 420
    [System.Media.SystemSounds]::Exclamation.Play()
    Start-Sleep -Milliseconds 420
    [System.Media.SystemSounds]::Exclamation.Play()
  } catch { }
}

# ---------------------------------------------------------------- 网络
function Send-Ack($id) {
  try {
    $b = '{"t":"ack","id":"' + $id + '","ts":' + [int64]([datetimeoffset]::UtcNow.ToUnixTimeMilliseconds()) + '}'
    Invoke-RestMethod -Uri $BASE -Method Post -Body $b -ContentType 'text/plain;charset=utf-8' -TimeoutSec 6 | Out-Null
  } catch { Write-Log ("回执失败: " + $_.Exception.Message) }
}

function Send-Ping {
  try {
    $b = '{"t":"ping","ts":' + [int64]([datetimeoffset]::UtcNow.ToUnixTimeMilliseconds()) + ',"room":"' + $ROOM + '"}'
    Invoke-RestMethod -Uri $BASE -Method Post -Body $b -ContentType 'text/plain;charset=utf-8' -TimeoutSec 6 | Out-Null
  } catch { }
}

function Poll-Ntfy {
  if ($script:BUSY) { return }
  $script:BUSY = $true
  try {
    $u = "$BASE/json?poll=1&since=$($script:LAST)"
    $raw = (Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 6).Content
    if ($raw -is [byte[]]) { $txt = [System.Text.Encoding]::UTF8.GetString($raw) }
    else { $txt = [string]$raw }

    foreach ($line in [regex]::Split($txt, '[\r\n]+')) {
      if ($line.Trim() -eq '') { continue }
      $o = $null
      try { $o = $line | ConvertFrom-Json } catch { continue }
      if ($o.event -ne 'message') { continue }
      if ($script:SEEN.ContainsKey([string]$o.id)) { continue }
      $script:SEEN[[string]$o.id] = 1
      if ([int64]$o.time -gt [int64]$script:LAST) { $script:LAST = [int64]$o.time }

      $p = $null
      try { $p = $o.message | ConvertFrom-Json } catch { $p = [pscustomobject]@{ t = 'msg'; text = [string]$o.message } }
      if ($null -eq $p) { continue }

      $kind = ''
      if ($p.PSObject.Properties.Name -contains 't') { $kind = [string]$p.t }

      switch ($kind) {
        'msg'   { Show-BigMessage $p; if ($p.id) { Send-Ack ([string]$p.id) } }
        'clear' { Reset-Screen }
        default { }
      }
    }
  } catch {
    # 网络暂时不通就算了，下一轮继续
  }
  $script:BUSY = $false
}

# ---------------------------------------------------------------- 定时器
$timerPoll = New-Object System.Windows.Forms.Timer
$timerPoll.Interval = 1500
[void]$timerPoll.Add_Tick({ Poll-Ntfy })

$timerPing = New-Object System.Windows.Forms.Timer
$timerPing.Interval = 20000
[void]$timerPing.Add_Tick({ Send-Ping })

# ---------------------------------------------------------------- 按钮
[void]$btnClear.Add_Click({ Reset-Screen })

[void]$btnQR.Add_Click({
  $script:QR_ON = -not $script:QR_ON
  $qrPanel.Visible = $script:QR_ON
  if ($script:QR_ON) { $qrPanel.BringToFront() }
})

# ---------------------------------------------------------------- 关闭 = 最小化
[void]$form.Add_FormClosing({
  param($s, $e)
  if (-not $script:EXITING) {
    $e.Cancel = $true
    $s.WindowState = [System.Windows.Forms.FormWindowState]::Minimized
    $lblMeta.Text = '已最小化到任务栏　·　来新消息会自动弹出来　·　右键窗口可退出'
  }
})

# ---------------------------------------------------------------- 启动
[void]$form.Add_Shown({
  # 从"现在"开始收，不回放历史消息（历史消息对教室没用）
  # 往前多取 10 秒：防止电脑时钟比服务器快，导致新消息被当成“旧的”漏掉
  $script:LAST = [int64][System.DateTimeOffset]::UtcNow.ToUnixTimeSeconds() - 10
  Set-BigText '大屏已就绪' 100
  $lblMeta.Text = '正在连接…　右键窗口可退出'
  Send-Ping
  $timerPoll.Start()
  $timerPing.Start()
  Write-Log "已启动，房间=$ROOM 主题=$TOPIC 起点=$script:LAST"
})

try {
  [System.Windows.Forms.Application]::Run($form)
} catch {
  Write-Log ("运行出错: " + $_.Exception.Message)
}

$timerPoll.Stop()
$timerPing.Stop()
Write-Log '已退出'
